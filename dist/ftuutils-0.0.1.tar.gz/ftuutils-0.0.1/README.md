A python library to create Functional Tissue Units using celltype models and their interconnection information. Library was developed to support the NZ MBIE 12 Labours project.
