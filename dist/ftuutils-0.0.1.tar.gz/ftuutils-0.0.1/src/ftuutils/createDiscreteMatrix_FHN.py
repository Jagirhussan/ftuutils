import numpy as np
from scipy.spatial import Delaunay
import networkx as nx
import matplotlib.pyplot as plt
from mpl_toolkits import mplot3d
import pickle

np.random.seed(0)

def plot_tri_simple(ax, points, tri):
    for tr in tri.simplices:
        pts = points[tr, :]
        ax.plot3D(pts[[0,1],0], pts[[0,1],1], pts[[0,1],2], color='g', lw='0.1')
        ax.plot3D(pts[[0,2],0], pts[[0,2],1], pts[[0,2],2], color='g', lw='0.1')
        ax.plot3D(pts[[0,3],0], pts[[0,3],1], pts[[0,3],2], color='g', lw='0.1')
        ax.plot3D(pts[[1,2],0], pts[[1,2],1], pts[[1,2],2], color='g', lw='0.1')
        ax.plot3D(pts[[1,3],0], pts[[1,3],1], pts[[1,3],2], color='g', lw='0.1')
        ax.plot3D(pts[[2,3],0], pts[[2,3],1], pts[[2,3],2], color='g', lw='0.1')

    ax.scatter(points[:,0], points[:,1], points[:,2], color='b')

def plotNetworkxGraph(G):
    pos = nx.get_node_attributes(G,"pos")
    # Extract node and edge positions from the layout
    node_xyz = np.array([pos[v] for v in sorted(G)])
    edge_xyz = np.array([(pos[u], pos[v]) for u, v in G.edges()])

    # Create the 3D figure
    fig = plt.figure()
    ax = fig.add_subplot(111, projection="3d")

    # Plot the nodes - alpha is scaled by "depth" automatically
    ax.scatter(*node_xyz.T, s=100, ec="w")

    # Plot the edges
    for vizedge in edge_xyz:
        ax.plot(*vizedge.T, color="tab:gray")


    def _format_axes(ax):
        """Visualization options for the 3D axes."""
        # Turn gridlines off
        ax.grid(False)
        # Suppress tick labels
        for dim in (ax.xaxis, ax.yaxis, ax.zaxis):
            dim.set_ticks([])
        # Set axes labels
        ax.set_xlabel("x")
        ax.set_ylabel("y")
        ax.set_zlabel("z")


    _format_axes(ax)
    fig.tight_layout()
    plt.show()

points = None

with open('D:/12Labours/OpenCMISS/DiscretePhysics/data/positions.npy', 'rb') as f:
    earr = np.load(f)
    xarr = np.load(f)
    points = np.load(f)

pids = np.arange(points.shape[0])
np.random.shuffle(pids)
maxpoints = pids.shape[0]//3
print(f"Selecting {maxpoints} of {pids.shape[0]}")
spids = pids[:maxpoints]

points = points[spids,:]

from base import FTUDelaunayGraph 
#Set edge weights based on orientation with respect to conductivity tensor
conductivity_tensor = np.array([1.2,0.9,0.5]) #Fibre sheet normal
g = FTUDelaunayGraph(points,"FHN",conductivity_tensor)

#Stimulus block is along the left wall
#Find nodes close to x start
left = np.min(points,axis=1)
leftpoints = np.isclose(points[:,0],left[0])
simb = []
#Get the nodes that are on the left edge
for i,v in enumerate(leftpoints):
    if v:
        simb.append(i)       
print("Input nodes",simb)
import json
import phsutils

#Provide a dictionary to store connection information
phsdata = {}

#Specify for each PHS class, for each input component the network on which it connects
phsdata = phsutils.connect(phsdata , 'FHN','u',1) #Connection on u

#Boundary connections can be specified as below. As a convention, boundary networks are negatively numbered
phsdata = phsutils.connectToBoundary(phsdata, 'FHN','i',-1) #Boundary connection for i

#Node that receive external inputs can be specified as below - these are boundary connections and the network no is negatively
#All external inputs with the same network number share the same input variable, if you want different input variable for each 
#external input, provide different network numbers
for ein in simb:
    phsdata = phsutils.addExternalInput(phsdata,ein,'u',-2)

#Set which networks are dissipative and add the information to the phsdata dictionary

networkDissipation = {1:True}
networkNames = {g.getDefaultNetworkID():"ucap",-1:"threshold",-2:"ubar"}

phsdata["networkNames"] = networkNames
phsdata["networkDissipation"] = networkDissipation

#Call resolve to resolve interactions and create the FTU
phsval = '{\"Hderivatives\":{\"cols\":1,\"elements\":[\"p/L\",\"q/C\"],\"rows\":2},\"hamiltonian\":\"(1/2)*(1/C)*q**2+(1/2)*(1/L)*p**2\",\"hamiltonianLatex\":\"\\\\left(\\\\frac{1}{2}\\\\right)\\\\frac{q^2}{C}+\\\\left(\\\\frac{1}{2}\\\\right)\\\\frac{p^2}{L}\",\"parameter_values\":{\"C\":{\"value\":\"0.5773\",\"units\":\"dimensionless\"},\"L\":{\"value\":\"1.7320\",\"units\":\"dimensionless\"},\"M\":{\"value\":\"p*p*p-3*p\",\"units\":\"dimensionless\"},\"r\":{\"value\":\"6\",\"units\":\"dimensionless\"}},\"portHamiltonianMatrices\":{\"matB\":{\"cols\":2,\"elements\":[\"1\",\"0\",\"0\",\"1\"],\"rows\":2},\"matE\":{\"cols\":2,\"elements\":[\"1\",\"0\",\"0\",\"1\"],\"rows\":2},\"matJ\":{\"cols\":2,\"elements\":[\"0\",\"-1\",\"1\",\"0\"],\"rows\":2},\"matQ\":{\"cols\":2,\"elements\":[\"1/L\",\"0\",\"0\",\"1/C\"],\"rows\":2},\"matR\":{\"cols\":2,\"elements\":[\"M\",\"0\",\"0\",\"1/r\"],\"rows\":2},\"u\":{\"cols\":1,\"elements\":[\"u\",\"i\"],\"rows\":2},\"u_orientation\":{\"cols\":1,\"elements\":[true,true],\"rows\":2}},\"stateVector\":{\"cols\":1,\"elements\":[\"p\",\"q\"],\"rows\":2},\"state_values\": {\"p\": {\"value\":\"0.5\",\"units\":\"dimensionless\"},\"q\": {\"value\":\"0.0\",\"units\":\"dimensionless\"}},\"success\":true}'  
phstypes = {'FHN':json.loads(phsval)}
G = g.getGraph()

composer = g.composeCompositePHS(G,phstypes,phsdata)
#composer.generateLatexReport()
ltxt = composer.exportAsPython()  

composer.save(composer,"D:\\12Labours\\GithubRepositories\\FTUcomposer\\ftuweaver\\data\\proceduralFTU.pkl")

with open("D:/Temp/dm1x.py","w") as f:
    print(ltxt,file=f)
       

# with open("D:/12Labours/OpenCMISS/DiscretePhysics/data/Graph.gpickle","wb") as f:
#     pickle.dump(G,f)

# plotNetworkxGraph(G)

#nx.draw(G, with_labels=True, node_size=500, node_color='lightgreen')
#plt.show()
# fig = plt.figure()
# ax = plt.axes(projection='3d')
# plot_tri_simple(ax, points, tri)
# plt.show()