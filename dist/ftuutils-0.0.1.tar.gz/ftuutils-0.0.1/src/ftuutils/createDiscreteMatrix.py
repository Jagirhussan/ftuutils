import numpy as np
from scipy.spatial import Delaunay
import networkx as nx
import matplotlib.pyplot as plt
from mpl_toolkits import mplot3d
import cloudpickle
import time

loadfile = False
if not loadfile:
    t0 = time.time()    
    np.random.seed(0)

    def plot_tri_simple(ax, points, tri):
        for tr in tri.simplices:
            pts = points[tr, :]
            ax.plot3D(pts[[0,1],0], pts[[0,1],1], pts[[0,1],2], color='g', lw='0.1')
            ax.plot3D(pts[[0,2],0], pts[[0,2],1], pts[[0,2],2], color='g', lw='0.1')
            ax.plot3D(pts[[0,3],0], pts[[0,3],1], pts[[0,3],2], color='g', lw='0.1')
            ax.plot3D(pts[[1,2],0], pts[[1,2],1], pts[[1,2],2], color='g', lw='0.1')
            ax.plot3D(pts[[1,3],0], pts[[1,3],1], pts[[1,3],2], color='g', lw='0.1')
            ax.plot3D(pts[[2,3],0], pts[[2,3],1], pts[[2,3],2], color='g', lw='0.1')

        ax.scatter(points[:,0], points[:,1], points[:,2], color='b')

    def plotNetworkxGraph(G):
        pos = nx.get_node_attributes(G,"pos")
        # Extract node and edge positions from the layout
        node_xyz = np.array([pos[v] for v in sorted(G)])
        edge_xyz = np.array([(pos[u], pos[v]) for u, v in G.edges()])

        # Create the 3D figure
        fig = plt.figure()
        ax = fig.add_subplot(111, projection="3d")

        # Plot the nodes - alpha is scaled by "depth" automatically
        ax.scatter(*node_xyz.T, s=100, ec="w")

        # Plot the edges
        for vizedge in edge_xyz:
            ax.plot(*vizedge.T, color="tab:gray")


        def _format_axes(ax):
            """Visualization options for the 3D axes."""
            # Turn gridlines off
            ax.grid(False)
            # Suppress tick labels
            for dim in (ax.xaxis, ax.yaxis, ax.zaxis):
                dim.set_ticks([])
            # Set axes labels
            ax.set_xlabel("x")
            ax.set_ylabel("y")
            ax.set_zlabel("z")


        _format_axes(ax)
        fig.tight_layout()
        plt.show()

    points = None

    with open('D:/12Labours/OpenCMISS/DiscretePhysics/data/positions.npy', 'rb') as f:
        earr = np.load(f)
        xarr = np.load(f)
        points = np.load(f)

    pids = np.arange(points.shape[0])
    np.random.shuffle(pids)
    maxpoints = pids.shape[0]//3
    print(f"Selecting {maxpoints} of {pids.shape[0]}")
    spids = pids[:maxpoints]

    points = points[spids,:]

    from base import FTUDelaunayGraph 
    #Set edge weights based on orientation with respect to conductivity tensor
    conductivity_tensor = np.array([1.2,0.9,0.5]) #Fibre sheet normal
    g = FTUDelaunayGraph(points,"APN",conductivity_tensor)

    #Stimulus block is along the left wall
    #Find nodes close to x start
    left = np.min(points,axis=1)
    leftpoints = np.isclose(points[:,0],left[0])
    simb = []
    #Get the nodes that are on the left edge
    for i,v in enumerate(leftpoints):
        if v:
            simb.append(i)       
    print("Input nodes",simb)
    import json
    import phsutils

    #Provide a dictionary to store connection information
    phsdata = {}

    #Specify for each PHS class, for each input component the network on which it connects
    phsdata = phsutils.connect(phsdata , 'APN','i_1',1) #Connection on u

    #Boundary connections can be specified as below. As a convention, boundary networks are negatively numbered

    #Node that receive external inputs can be specified as below - these are boundary connections and the network no is negatively
    #All external inputs with the same network number share the same input variable, if you want different input variable for each 
    #external input, provide different network numbers
    for ein in simb:
        phsdata = phsutils.addExternalInput(phsdata,ein,'i_1',-2)

    #Set which networks are dissipative and add the information to the phsdata dictionary
    defaultNetworkId = g.getDefaultNetworkID()
    networkDissipation = {defaultNetworkId:True}
    networkNames = {defaultNetworkId:"ucap",-2:"ubar"}

    phsdata["networkNames"] = networkNames
    phsdata["networkDissipation"] = networkDissipation

    #Call resolve to resolve interactions and create the FTU
    phsval = r'{"parameter_values":{"eps0":{"value":"0.002","units":"dimensionless"},"k":{"value":"8.0","units":"dimensionless"},"a":{"value":"0.13","units":"dimensionless"},"c0":{"value":"0.016602","units":"dimensionless"},"ct":{"value":"0.0775","units":"dimensionless"},"mu1":{"value":"0.2","units":"dimensionless"},"mu2":{"value":"0.3","units":"dimensionless"},"x1":{"value":"0.0001","units":"dimensionless"},"x2":{"value":"0.78","units":"dimensionless"},"x3":{"value":"0.2925","units":"dimensionless"},"eta1":{"value":"Tai*(Heaviside(u-x2)*Heaviside(x3-Tai)*(x1-c0)+c0)","units":"dimensionless"},"eta2":{"value":"Heaviside(u-x2)*Heaviside(x3-Tai)*(x1-c0)+c0","units":"dimensionless"},"sigma":{"value":"0.042969","units":"dimensionless"},"sqpi":{"value":"sqrt(2*3.141459265)","units":"dimensionless"},"kV":{"value":"exp(-0.5*((u-1)/sigma)**2)/(sigma*sqpi)","units":"dimensionless"},"U":{"value":"k*u*(u-a)*(1-u)-u*v","units":"dimensionless"},"V":{"value":"(eps0+(v*mu1)/(u+mu2))*(-v-k*u*(u-a-1))","units":"dimensionless"}},"Hderivatives":{"cols":1,"rows":4,"elements":["Tai","Ta","u","v"]},"hamiltonianLatex":"- Ta c_{0} kV + \\frac{Tai^{2} eta1}{2} - \\frac{eps0 k u^{3}}{3} + \\frac{eps0 k u^{2} \\left(a + 1\\right)}{2} - i_{1} v","hamiltonian":"eps0*k*((a+1)*u**2)/2 - eps0*k*u**3/3 + eta1*Tai**2/2 - c0*kV*Ta - (i_1)*v","portHamiltonianMatrices":{"matJ":{"cols":4,"rows":4,"elements":["0","- eta1/2","c0*kV/2","0","eta1/2","0","0","0","-c0*kV/2","0","0","0","0","0","0","0"]},"matR":{"cols":4,"rows":4,"elements":["c0","-eta1/2","-c0*kV/2","0","-eta1/2","eta2","0","0","-c0*kV/2","0","-U","0","0","0","0","-V"]},"matB":{"cols":4,"rows":4,"elements":["0","0","0","0","0","0","0","0","0","0","1/ct","0","0","0","0","0"]},"matBhat":{"cols":0,"rows":0,"elements":[]},"matQ":{"cols":4,"rows":4,"elements":["1","0","0","0","0","1","0","0","0","0","1","0","0","0","0","1"]},"matE":{"cols":4,"rows":4,"elements":["1","0","0","0","0","1","0","0","0","0","1/ct","0","0","0","0","1/ct"]},"matC":{"cols":0,"rows":0,"elements":[]},"u":{"cols":1,"rows":4,"elements":["0","0","i_1","0"]},"u_connect2boundary":{"cols":1,"elements":[false,false,false,false],"rows":4}},"stateVector":{"cols":1,"rows":4,"elements":["Tai","Ta","u","v"]},"state_values":{"Tai":{"value":0.000,"units":"dimensionless"},"Ta":{"value":0.001,"units":"dimensionless"},"u":{"value":0,"units":"dimensionless"},"v":{"value":0.03604,"units":"dimensionless"}},"isphenomenological":false,"success":true}'
    phstypes = {'APN':json.loads(phsval)}
    G = g.getGraph()

    composer = g.composeCompositePHS(G,phstypes,phsdata)
    t1 = time.time()
    total = t1-t0
    print(f"Time for composition {total}")
    #t0 = time.time()
    # with open("D:/Temp/apn.pkl",'wb') as ser:
    #     cloudpickle.dump(composer,ser)
    # t1 = time.time()
    #total = t1-t0
    #print(f"Time for saving {total}")    
else:
    defaultNetworkId = 1
    with open("D:/Temp/apn.pkl",'rb') as ser:
        composer = cloudpickle.load(ser)

code = """
i_1 = 0
if t>100 and t<110:
    i_1 = 0.5
"""

from simulationutils import SimulationExperiment

sim = SimulationExperiment(composer)    
sim.addExperiment('test',[0,600,600],code)
sim.generate(r'D:\Temp\ftusimset')

'''    
#composer.generateLatexReport()
t0 = time.time()
ltxt = composer.exportAsPython()  

t1 = time.time()
total = t1-t0
print(f"Time for export {total}")

with open("D:/Temp/apn.py","w") as f:
    print(ltxt,file=f)

oltxt = composer.exportAsODEStepper()
with open("D:/Temp/ftuclass.py","w") as f:
    print(oltxt,file=f)
       
#Edge weight corresponds to network id
composer.saveDiscreteExteriorCalculusOperators(r'D:\Temp\ftuop',defaultNetworkId)
    
# with open("D:/12Labours/OpenCMISS/DiscretePhysics/data/Graph.gpickle","wb") as f:
#     pickle.dump(G,f)

# plotNetworkxGraph(G)

#nx.draw(G, with_labels=True, node_size=500, node_color='lightgreen')
#plt.show()
# fig = plt.figure()
# ax = plt.axes(projection='3d')
# plot_tri_simple(ax, points, tri)
# plt.show()
'''