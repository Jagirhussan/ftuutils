import torch
from torchmin import minimize
import numpy as np
from collections import OrderedDict
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
torch.manual_seed(0)
 
class DDECOperator(torch.nn.Module):
    
    def __init__(self,boundaryOperator,*args, **kwargs) -> None:
        """Create a DDEC Operator to fit node, flux correlations

        Args:
            boundaryOperator (np.array): Boundary operator of the 1-form
        """
        super().__init__(*args, **kwargs)
        self.boundaryOperator = boundaryOperator
        self.coBoundaryOperator = np.transpose(boundaryOperator)
        r,c = boundaryOperator.shape
        self.B2dim = c
        self.B1dim = r
        self.D2dim = c
        self.D1dim = r        
        self.Rdim  = r
        self.epsilon = 0.1
        self.numnodes = c #Number of nodes in the complex
        numcomponents = r #Number of flux vector components
        self.co = torch.Tensor(self.coBoundaryOperator)
        self.bo = torch.Tensor(self.boundaryOperator)
        self.B2 = torch.nn.Parameter(torch.abs(torch.randn(self.B2dim)))
        self.B1inv = torch.nn.Parameter(torch.abs(torch.randn(self.B1dim)))
        self.D2 = torch.nn.Parameter(torch.abs(torch.randn(self.D2dim)))
        self.D1iv = torch.nn.Parameter(torch.abs(torch.randn(self.D1dim)))
        
        self.Rinv= torch.nn.Parameter(-torch.abs(torch.randn(self.Rdim)))        
        self.costar = torch.matmul(torch.diag(self.Rinv),self.bo)
        
        #self.DIV_h = torch.matmul(torch.matmul(torch.diag(self.B2),self.co),torch.diag(self.B1inv))
        #self.GRADstar_h= torch.matmul(torch.matmul(torch.diag(self.D1iv),self.costar),torch.diag(self.D2))
        
        self.operator = torch.zeros(r+c,r+c)
        #Operator for nograd operations
        self.operatorng = torch.zeros(r+c,r+c)
        
        print(f"DDECOpertor setup with {c} number of nodes and {r} edges")

    def getDivh(self):
        return torch.matmul(torch.matmul(torch.diag(self.B2),self.co),torch.diag(self.B1inv))

    def getGradstarh(self):
        return torch.matmul(torch.matmul(torch.diag(self.D1iv),self.costar),torch.diag(self.D2))        

    @torch.no_grad
    def getUandLamdbaParameter(self,i0:torch.Tensor,i1:torch.Tensor,fdenom:torch.Tensor):
        """Solve for i given current operator parameters and i1
           Using minimize to determine both the solution and the gradient
           required to calculate lambda.
           These calculations should not impact the parameter gradients with respect to final loss calculation,
           the no_grad decoration is used to effect this 
        Args:
            i0 (torch.Tensor): input at time t
            i1 (torch.Tensor): boundary conditions are time t
        Returns:
            (torch.Tensor,float): i for current parameters and given i0, lambda
        """
        r = self.B1dim
        c = self.B2dim        
        #These need to be calculated based on the parameters
        costar = torch.matmul(torch.diag(self.Rinv),self.bo)
        self.operatorng[0:r,0:c] = -torch.matmul(torch.matmul(torch.diag(self.D1iv),costar),torch.diag(self.D2))
        self.operatorng[0:r,c:] = torch.eye(r)
        self.operatorng[r:,c:] = torch.matmul(torch.matmul(torch.diag(self.B2),self.co),torch.diag(self.B1inv))
                

        def uloss(ux):
            lhs = torch.matmul(self.operatorng,ux)  
            return (((lhs - i1))**2).sum()
        
        uinit = i0+1e-4*torch.randn(i0.shape)
        res = minimize(
                uloss, uinit, 
                method='newton-cg',
                options=dict(line_search='strong-wolfe'),
                # method='newton-exact',
                # options=dict(line_search='strong-wolfe', tikhonov=1e-4),     
                # method='bfgs', 
                # options=dict(line_search='strong-wolfe'),                                          
                max_iter=500, 
                disp=0
            )
        if res.success==False:
            res = minimize(
                    uloss, uinit, 
                    method='newton-cg',
                    options=dict(line_search='strong-wolfe'),
                    # method='newton-exact',
                    # options=dict(line_search='strong-wolfe', tikhonov=1e-4),     
                    # method='bfgs', 
                    # options=dict(line_search='strong-wolfe'),                                          
                    max_iter=500, 
                    disp=0
                )
            

        lamda = torch.abs(2*torch.matmul(res.grad,i0-res.x))
        #print(res)
        return res.x,lamda
        
    def forward(self,input):
        """Compute fluxes for given potentials

        Args:
            input (torch.Tensor): {numcomponents potentials + number of edges fluxes}x1 vector of node potentials
        """
        #DIV_H is a cxr tensor, GRAD_H is a rxc tensor
        #Create the operator
        '''
         -Gradstarh*u0 +       f0 = 0
                        Div_h*f0 = f1
        '''          
        r = self.B1dim
        c = self.B2dim
        #Create operator based on current parameter values
        self.costar = torch.matmul(torch.diag(self.Rinv),self.bo)        
        self.operator[0:r,0:c] = -torch.matmul(torch.matmul(torch.diag(self.D1iv),self.costar),torch.diag(self.D2))
        self.operator[0:r,c:] = torch.eye(r)
        
        self.operator[r:,c:] = torch.matmul(torch.matmul(torch.diag(self.B2),self.co),torch.diag(self.B1inv))
        

        return torch.matmul(self.operator,input)


        
def computeGradientsForParameterUpdate(d:DDECOperator,i0:torch.Tensor,i1:torch.Tensor):
    """Logic for computing gradients for parameters

    Args:
        d (DDECOperator): DDECOperator instance
        i0 (torch.Tensor): Inputs
        i1 (torch.Tensor): boundary conditions are time t
    Returns:
        (float): Loss
    """
    #Get the lhs vector that closesly matches the boundary conditions for the current parameter values
    #and the penalty term l for computing loss
    X,l = d.getUandLamdbaParameter(i0,i1)

    loss = ((X-i0)**2 + l*(d(X)-i1)**2).sum()
   
    lval = loss.item() #Calculate loss        
    # backward pass for computing the gradients of the loss w.r.t to learnable parameters
    loss.backward(retain_graph=True)

    return lval
   
if __name__ == '__main__':
    bo = np.zeros((3,4))
    bo[0,0] = -1
    bo[0,1] = 1
    bo[1,1] = -1
    bo[1,2] = 1
    bo[2,1] = -1
    bo[2,3] = 1
    
    model = DDECOperator(bo)
